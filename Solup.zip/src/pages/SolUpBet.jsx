import React from 'react'

const SolUpBet = () => {
  return (
    <div>
      SolUpBet
    </div>
  )
}

export default SolUpBet;
