import React from 'react'
import Portfolio from '../../components/Pools'

const PortfolioPools = () => {
  return (
    <div>
      <Portfolio/>
    </div>
  )
}

export default PortfolioPools
