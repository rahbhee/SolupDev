import React from 'react'

const Loans = () => {
  return (
    <div>
      
    </div>
  )
}

export default Loans
