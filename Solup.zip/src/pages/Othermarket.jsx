import React from 'react'

const Othermarket = () => {
  return (
    <div>
      other market
    </div>
  )
}

export default Othermarket
