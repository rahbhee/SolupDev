import React from 'react'

const Success = () => {
  return (
    <div classsName='flex items-center '>
      <h1 className='align-center success text-3xl font-bold my-40'>SignUp Successful!</h1>
    </div>
  )
}

export default Success
