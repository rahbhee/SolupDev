import React from 'react'

const ProjectCreator = () => {
  return (
    <div>
      Project creator
    </div>
  )
}

export default ProjectCreator
