import React from 'react'

const BasicTrader = () => {
  return (
    <div>
      Basic trader
    </div>
  )
}

export default BasicTrader
